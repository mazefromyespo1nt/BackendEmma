package com.reporter.pdf.casinorep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasinorepApplicationTests {

	@Test
	void contextLoads() {
	}

}
