package com.service.users.authservice.commons;

public class ResourcesConstants {
	protected final String res = "";
}
